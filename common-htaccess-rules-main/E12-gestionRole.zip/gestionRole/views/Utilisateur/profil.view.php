<h1>Profil de <?= $utilisateur['login'] ?></h1>
<div id="mail">
    Mail : <?= $utilisateur['mail'] ?>
</div>
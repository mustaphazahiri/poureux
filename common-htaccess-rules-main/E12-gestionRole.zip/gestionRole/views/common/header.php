<div class="container">
  <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom">
    <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
      <img src="<?= URL; ?>public/Assets/images/logo.png" width="40" alt="logo du site" />
      <span class="ms-5 fs-4">Mon super site</span>
    </a>

    <?php require_once("views/common/menu.php"); ?>
  </header>
</div>

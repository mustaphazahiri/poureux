<?php
require_once("Model.class.php");

abstract class MainManager extends Model{

}